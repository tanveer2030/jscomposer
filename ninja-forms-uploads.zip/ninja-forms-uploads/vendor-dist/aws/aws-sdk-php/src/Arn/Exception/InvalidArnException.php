<?php

namespace NF_FU_VENDOR\Aws\Arn\Exception;

/**
 * Represents a failed attempt to construct an Arn
 */
class InvalidArnException extends \RuntimeException
{
}
