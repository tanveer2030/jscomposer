<?php

namespace NF_FU_VENDOR;

// This file was auto-generated from sdk-root/src/data/appmesh/2019-01-25/paginators-1.json
return ['pagination' => ['ListMeshes' => ['input_token' => 'nextToken', 'limit_key' => 'limit', 'output_token' => 'nextToken', 'result_key' => 'meshes'], 'ListRoutes' => ['input_token' => 'nextToken', 'limit_key' => 'limit', 'output_token' => 'nextToken', 'result_key' => 'routes'], 'ListTagsForResource' => ['input_token' => 'nextToken', 'limit_key' => 'limit', 'output_token' => 'nextToken', 'result_key' => 'tags'], 'ListVirtualNodes' => ['input_token' => 'nextToken', 'limit_key' => 'limit', 'output_token' => 'nextToken', 'result_key' => 'virtualNodes'], 'ListVirtualRouters' => ['input_token' => 'nextToken', 'limit_key' => 'limit', 'output_token' => 'nextToken', 'result_key' => 'virtualRouters'], 'ListVirtualServices' => ['input_token' => 'nextToken', 'limit_key' => 'limit', 'output_token' => 'nextToken', 'result_key' => 'virtualServices']]];
