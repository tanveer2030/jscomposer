<?php

namespace NF_FU_VENDOR;

// This file was auto-generated from sdk-root/src/data/es/2015-01-01/paginators-1.json
return ['pagination' => ['DescribeReservedElasticsearchInstanceOfferings' => ['input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults'], 'DescribeReservedElasticsearchInstances' => ['input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults'], 'GetUpgradeHistory' => ['input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults'], 'ListElasticsearchInstanceTypes' => ['input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults'], 'ListElasticsearchVersions' => ['input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults']]];
