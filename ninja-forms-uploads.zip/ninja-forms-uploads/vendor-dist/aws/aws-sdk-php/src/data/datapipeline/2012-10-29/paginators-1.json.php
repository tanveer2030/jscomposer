<?php

namespace NF_FU_VENDOR;

// This file was auto-generated from sdk-root/src/data/datapipeline/2012-10-29/paginators-1.json
return ['pagination' => ['ListPipelines' => ['input_token' => 'marker', 'output_token' => 'marker', 'more_results' => 'hasMoreResults', 'result_key' => 'pipelineIdList'], 'DescribeObjects' => ['input_token' => 'marker', 'output_token' => 'marker', 'more_results' => 'hasMoreResults', 'result_key' => 'pipelineObjects'], 'DescribePipelines' => ['result_key' => 'pipelineDescriptionList'], 'QueryObjects' => ['input_token' => 'marker', 'output_token' => 'marker', 'more_results' => 'hasMoreResults', 'limit_key' => 'limit', 'result_key' => 'ids']]];
