<?php

namespace NF_FU_VENDOR;

// This file was auto-generated from sdk-root/src/data/frauddetector/2019-11-15/paginators-1.json
return ['pagination' => ['DescribeModelVersions' => ['input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults'], 'GetDetectors' => ['input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults'], 'GetExternalModels' => ['input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults'], 'GetModels' => ['input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults'], 'GetOutcomes' => ['input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults'], 'GetRules' => ['input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults'], 'GetVariables' => ['input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults']]];
