<?php

namespace NF_FU_VENDOR;

// This file was auto-generated from sdk-root/src/data/config/2014-11-12/paginators-1.json
return ['pagination' => ['DescribeRemediationExceptions' => ['input_token' => 'NextToken', 'limit_key' => 'Limit', 'output_token' => 'NextToken'], 'DescribeRemediationExecutionStatus' => ['input_token' => 'NextToken', 'limit_key' => 'Limit', 'output_token' => 'NextToken', 'result_key' => 'RemediationExecutionStatuses'], 'GetResourceConfigHistory' => ['input_token' => 'nextToken', 'limit_key' => 'limit', 'output_token' => 'nextToken', 'result_key' => 'configurationItems']]];
