<?php

namespace NF_FU_VENDOR;

// This file was auto-generated from sdk-root/src/data/elastic-inference/2017-07-25/paginators-1.json
return ['pagination' => []];
